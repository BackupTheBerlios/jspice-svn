static char RCSid[] =
"$Header: c:/tads/tads2/RCS/dummy.c 1.3 93/01/08 04:33:17 mroberts Exp $";

/* Copyright (c) 1992 by Michael J. Roberts.  All Rights Reserved. */
/*
Name
  dummy.c - TEMPORARY dummy file for resolving symbols
Function
  Resolves certain symbols while linking with old tads 1.x output layer
Notes
  should be removed as soon as new output layer is written
Modified
  02/16/92 MJRoberts     - creation
*/

#include <stdio.h>

int tadsdebug;
int biexcnt;
int biextab;
int dbgactive;

